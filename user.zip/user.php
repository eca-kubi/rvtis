<?php
$secretword = 'tims-dope';
$username = 'anonymous user';
ob_start();
session_name('client');
session_start();
//session_set_cookie_params(time() + 86400);
/*if (isset($_COOKIE["user"])) {
  setcookie(session_name(), session_id(), time() + 86400);
}*/
if (isset($_SESSION['client'])) {
	$who = 'client';
	$username = $_SESSION['client'];
} else {
  header("Location:index.php");
  exit;
}

?>
	<!DOCTYPE html>
	<html lang="en">

	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<title>TIMS&copy; User</title>
		<script src="https://cdn.pubnub.com/sdk/javascript/pubnub.4.20.0.js"></script>
		<link rel="stylesheet" href="assets/css/w3.css">
		<link rel="stylesheet" href="assets/css/ionicons.css">
		<link rel="stylesheet" href="assets/css/font-awesome.css">
		<link rel="stylesheet" href="assets/css/bootstrap.css">
		<link rel="stylesheet" href="assets/AdminLTE/css/AdminLTE.css">
		<link rel="stylesheet" href="assets/jquery-ui/themes/cupertino/jquery-ui.min.css">
		<link rel="stylesheet" href="assets/datatable.net/css/datatables.min.css">
		<link rel="stylesheet" href="assets/datatable.net/css/dataTables.bootstrap.min.css">
		<link rel="stylesheet" href="assets/datatable.net/responsive/css/responsive.bootstrap.min.css">
		<link rel="stylesheet" href="assets/css/custom.css">
	</head>

	<body>
		<div class="">
			<nav class="navbar navbar-default m-b-0">
				<div class="container-fluid">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed w3-padding-24" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"
						  aria-expanded="false">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar margin-bottom"></span>

						</button>

						<a class="navbar-brand" href="#">Welcome,
							<?php echo $username; ?> </a>
						<ul style="list-style: none" class="w3-padding-16 hide">
							<li class="dropdown notifications-menu" style="margin-right: 32px">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
									<i class="fa fa-bell-o"></i>
									<span class="label label-warning"></span>
								</a>
								<ul class="dropdown-menu">
									<li class="header dropdown-header">You have 10 notifications</li>
									<li>
										<!-- inner menu: contains the actual data -->
										<ul class="menu list-group">
											<li class="list-group-item d">
												<a href="#">
													<i class="fa fa-users text-aqua"></i> 5 new members joined today
												</a>
											</li>
											<li class="list-group-item">
												<a href="#">
													<i class="fa fa-warning text-yellow"></i> Very long description here that may not fit into the page and may cause design problems
												</a>
											</li>
										</ul>
									</li>
									<li class="footer">
										<a href="#">View all</a>
									</li>
								</ul>
							</li>
						</ul>
					</div>

					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						<ul class="nav navbar-nav">
							<li class="active hidden">
								<a href="#">Link
									<span class="sr-only">(current)</span>
								</a>
							</li>
							<li class="hide">
								<a href="#">
									<span class="ion ion-android-send"></span> Send Tow Service Request</a>
							</li>
							<li class="hide">
								<a href="#">
									<span class="ion ion-help"></span> FAQ</a>
							</li>
							<li>
								<a href="#">
									<span class="fa fa-info-circle "></span> About</a>
							</li>
							<li>
								<a href="sign-out.php?who=client&username=<?php echo $username; ?>">
									<span class="ion ion-locked"></span> Sign Out</a>

							</li>
							<li class="dropdown hidden">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Dropdown
									<span class="caret"></span>
								</a>
								<ul class="dropdown-menu">
									<li>
										<a href="#">Action</a>
									</li>
									<li>
										<a href="#">Another action</a>
									</li>
									<li>
										<a href="#">Something else here</a>
									</li>
									<li role="separator" class="divider"></li>
									<li>
										<a href="#">Separated link</a>
									</li>
									<li role="separator" class="divider"></li>
									<li>
										<a href="#">One more separated link</a>
									</li>
								</ul>
							</li>
						</ul>
						<form class="navbar-form navbar-right">
							<div class="form-group">
								<div class="input-group">
									<input type="text" class="form-control" style="border: 0" placeholder="Search Company">
									<span class="times-bar w3-text-dark-gray w3-hover-text-blue-gray" role="button">&timesbar;</span>
								</div>
							</div>
							<button type="submit" class="btn btn-default">Submit</button>
						</form>
						<ul class="nav navbar-nav navbar-right hidden">
							<li>
								<a href="#">Link</a>
							</li>
							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Dropdown
									<span class="caret"></span>
								</a>
								<ul class="dropdown-menu">
									<li>
										<a href="#">Action</a>
									</li>
									<li>
										<a href="#">Another action</a>
									</li>
									<li>
										<a href="#">Something else here</a>
									</li>
									<li role="separator" class="divider"></li>
									<li>
										<a href="#">Separated link</a>
									</li>
								</ul>
							</li>
						</ul>
					</div>
					<!-- /.navbar-collapse -->
				</div>
				<!-- /.container-fluid -->
			</nav>

			<div class="row  well">
				<div class="description  row">
					<div class="modal fade" id="modal-towrequestform">
						<div class="modal-dialog" role="document">
							<div class="modal-content">
								<div class="modal-header">
									<h5 class="modal-title">
										<span class="ion ion-android-send"></span> Send Tow Request</h5>
									<button type="button" class="close" data-dismiss="modal" aria-label="Close">
										<span aria-hidden="true">&times;</span>
									</button>
								</div>
								<div class="modal-body">
									<form action="" method="post" name="towrequestform" id="towrequestform">
										<div class="form-group" id="registrationnumber">
											<div class="input-group">
												<span class="input-group-addon fa fa-sort-numeric-asc"></span>
												<input class="form-control required" type="text" name="registrationnumber" placeholder="Car Registration Number">
											</div>
											<div class="control-feedback hide">This field is required!</div>
										</div>
										<div class="form-group">
											<div class="input-group">
												<span class="input-group-addon ion ion-android-bus"></span>

												<select name="cartype" class="form-control required">
													<option value="" selected>Select Car Type</option>
													<option value="salon">Salon Car</option>
													<option value="4x4">4X4</option>
													<option value="pickup">Pickup</option>
													<option value="minivan">Mini Van</option>
												</select>
											</div>
											<div class="control-feedback hide">Please select a car type</div>
										</div>
										<div class="form-group">
											<div class="input-group">
												<span class="input-group-addon fa fa-car"></span>
												<input class="form-control" type="text" name="vehiclemake" placeholder="Vehicle Make">
											</div>
										</div>
										<div class="control-feedback hide"></div>
										<div class="form-group">
											<div class="input-group">
												<span class="input-group-addon ion ion-model-s"></span>
												<input class="form-control" type="text" name="vehiclemodel" placeholder="Vehicle Model">
											</div>
										</div>
										<div class="control-feedback hide"></div>
										<div class="form-group">
											<div class="input-group">
												<span class="input-group-addon ion ion-document"></span>
												<input class="form-control" type="text" name="description" placeholder="Description">

											</div>
											<small>Provide a short description of the problem here</small>
										</div>
										<input type="hidden" name="locationlng">
										<input type="hidden" name="locationlat">
										<input type="hidden" name="username" value="<?php echo $username; ?>">
									</form>
								</div>
								<div class="modal-footer">
									<button type="submit" class="btn btn-primary" data-companyusername="" form="towrequestform">Send Tow Request</button>
									<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
								</div>
							</div>
						</div>
						<button class="hide" data-target="#modal-towrequestform" data-toggle="modal"></button>
					</div>
					<div class="w3-padding-large">
						<h4>View tow companies within </h4>
						<div id="slider" class="w3-margin">
							<div id="custom-handle" class="ui-slider-handle"></div>
							<input type="hidden" name="" id="slider-value">
						</div>
						<div class="table-responsive">
							<table class="table table-bordered table-company table-striped">
								<thead class="w3-amber">
									<tr>
										<th>Company</th>
										<th>Location</th>
										<th>Distance</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody class="">
								</tbody>
							</table>
						</div>

					</div>
					<div class="location-screen col-lg-12 w3-margin-top">
						<h4>
							<span class="ion ion-android-map"> Your Location</span>
						</h4>
						<div id="map">
							<div class="center-block">
								<span class="ion ion-navigate"></span> Map</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<script src="assets/js/jquery.js"></script>
		<script src="assets/jquery-ui/jquery-ui.js"></script>
		<!--<script src="assets/js/jquery.sglide.latest.min.js"></script>-->
		<script src="assets/js/bootstrap.js"></script>
		<script src="assets/js/tether.min.js"></script>
		<script src="assets/AdminLTE/js/adminlte.min.js"></script>
		<script src="assets/js/jquery.easing.1.3.js"></script>
		<script src="assets/datatable.net/js/datatables.min.js"></script>
		<script src="assets/datatable.net/js/dataTables.bootstrap.min.js"></script>
		<script src="assets/datatable.net/responsive/js/responsive.bootstrap.min.js"></script>
		<script>
			//# sourceURL=user.js
			var map;
			var pubnub;
			var watchid;
			var locationlng;
			var locationlat;
			var username;
			var myprivatechannel;
			var towresponse = {};
			window.currentlocation = {
				lat: 7.349246666666667,
				lng: -2.341495
			};
			var clientpayload = {};
			var companypayload = {};
			var job;
			var myInfoWindow;
			var myMarker;
			window.onload = function (params) {
				username = $("input[name='username']").val();
				if ("geolocation" in navigator) {
					navigator.geolocation.getCurrentPosition(function success(position) {
						window.currentlocation.lat = position.coords.latitude;
						window.currentlocation.lng = position.coords.longitude;
					}, function error(params) {}, {
						timeout: 50000,
						maximumAge: 10000,
						enableHighAccuracy: true
					});

					watchid = navigator.geolocation.watchPosition(function success(position) {
						window.currentlocation.lat = position.coords.latitude;
						window.currentlocation.lng = position.coords.longitude;
						map.panTo(window.currentlocation);
						myMarker.setPosition(window.currentlocation);
					}, function error(params) {}, {
						timeout: 50000,
						maximumAge: 10000,
						enableHighAccuracy: true
					});
				}

				if ("PubNub" in window) {
					pubnub = new PubNub({
						publishKey: 'pub-c-cb902de7-4d32-42f1-b755-09518db50855',
						subscribeKey: 'sub-c-1adc0c20-01bf-11e8-91aa-36923a88c219'
					});
					pubnub.subscribe({
						channels: ['pubnub-userapp', username],
						withPresence: true
					});
					pubnub.addListener({
						presence: function (presenceEvent) {
							console.log('presence event came in: ', presenceEvent);
						},
						message: function (payload) {
							var username = payload.message.username || "";
							var currentaddress = payload.message.currentaddress || "Unknown Road";
							var latlng1 = payload.message.currentlocation;
							var latlng2 = window.currentlocation;
							var distance = parseFloat(google.maps.geometry.spherical.computeDistanceBetween(new google
								.maps.LatLng(latlng1.lat, latlng1.lng), new google.maps.LatLng(
									latlng2.lat, latlng2.lng)) / 1000).toFixed(2);
							var who = payload.message.who;
							var message = payload.message;
							var row =
								`<tr><td data-name='${username}'>${username}</td><td>${currentaddress}</td><td>${distance} km away</td><td><a role='button' class='btn btn-primary center-block' type='button' data-name='${username}'><span class='fa fa-send'></span> Send Request</a></td></tr>`;
							if (who == 'company') {
								if ('action_response' in message) {
									if (message.action_response == 'current_location' && ($("#slider-value").val() >= distance)) {
										if ($(`table.table-company td[data-name='${username}']`).length == 0) {
											window.companytable.row.add([username, currentaddress, distance + ' km away',
												`<a role='button' class='btn btn-primary center-block' type='button' data-name='${username}'><span class='fa fa-send'></span> Send Request</a>`
											]).draw(false);
										} else {
											var table = window.companytable;
											var data = table.row(`[data-name='${username}']`).data();
											data[1] = currentaddress;
											data[2] = distance + " km away";
											table.row(`[data-name='${username}']`).data(data).draw(false);
										}
									}
								}
							}
							if (who == 'company') {

							}
						}
					});
					setInterval(function name(params) {
						publish({
							username: window.username,
							who: 'client',
							action_request: 'current_location'
						}, 'pubnub-company');
					}, 30000);
				}

				$('.table-company').on('click', 'tbody tr td a', function name(params) {
					var username = $(this).attr('data-name');
					var currentlocation = window.currentlocation;
					$("button.btn-primary[form=towrequestform]").attr('data-companyusername', username);
					$("button[data-target='#modal-towrequestform']").click();
				});

				$("#towrequestform").on("submit", function submitform(evt) {
					var companyusername = $("button.btn-primary[form=towrequestform]").attr(
						'data-companyusername');
					$(".has-error").removeClass("has-error");
					$(".control-feedback").addClass("hide");
					let inputs = $(".form-group input.form-control.required");
					let error = 0;
					inputs.each(function (index, elem) {
						$elem = $(elem);
						if ($elem.val() == "") {
							$elem.parents(".form-group")
								.addClass("has-error")
								.children(".control-feedback")
								.removeClass("hide");
							error++;
							if ($elem.attr("name") == "registrationnumber") {
								location.href = "#";
								location.href = "#top";
							}
						}
					});
					if (error !== 0) {
						evt.preventDefault();
						return false;
					}
					$.post("tow-request.php", $("#towrequestform").serialize())
						.done(function (result) {
							try {
								let json = JSON.parse(result);
								if (json.success) {
									message = {};
									message.vehiclenumber = $("input[name='registrationnumber']").val();
									message.location = window.currentlocation;
									message.currentlocation = window.currentlocation;
									message.who = "client";
									message.username = window.username;
									message.towrequested = true;
									publish(message, companyusername);
									console.log("Tow request sent: " + JSON.stringify(message));
									alert("Tow request sent succesfully!");
								} else {
									if (!json.success) {
										location.href = "#";
										location.href = "#top";
									}
									if ("registrationnumber" in json) {
										let input = $("input[name='registrationnumber']").focus();
										input.parents(".form-group")
											.children(".control-feedback")
											.html(
												`<span class='text-danger'>${json.registrationnumber}</span>`
											);
									}
									if ("cartype" in json) {
										let input = $("select[name='cartype']");
										input.parents(".form-group")
											.addClass("has-error")
											.children(".control-feedback")
											.removeClass("hide")
											.html(`<span class='text-danger'>${json.cartype}</span>`);
									}
								}

							} catch (error) {
								console.log(error);
							}
						})
						.fail(function (error) {
							alert("No Internet connection!");
							console.log(error);
						});
					evt.preventDefault();
				});
			}

			function initializemap() {
				var mScript = document.createElement('script');
				var smScript = document.createElement('script');
				smScript.onload = function (params) {
					SlidingMarker.initializeGlobally();
				}
				var omsScript = document.createElement('script');
				map = new google.maps.Map(document.getElementById("map"), {
					center: window.currentlocation,
					zoom: 15
				});
				myInfoWindow = new google.maps.InfoWindow;
				myMarker = new google.maps.Marker({
					position: window.currentlocation,
					map: map,
					title: "Me",
					animation: google.maps.Animation.DROP
				});
				myMarker.addListener('click', function () {
					getAddress(window.currentlocation).then(function (address) {
						myInfoWindow.setContent('<b>Current address: </b>' + address);
						setTimeout(() => {
							myInfoWindow.close();
						}, 5000);
						myInfoWindow.open(map, myMarker);
					});
				});
				omsScript.async = true;
				omsScript.defer = true;
				omsScript.onload = function (params) {
					var oms = new OverlappingMarkerSpiderfier(map, {
						ignoreMapClick: true
					});
					window.oms = oms;
					mScript.src = "assets/js/markerAnimate.js";
					smScript.src = "assets/js/SlidingMarker.min.js";
					omsScript.src = "assets/js/oms.min.js"
					document.body.appendChild(mScript);
					document.body.appendChild(smScript);
					document.body.appendChild(omsScript);
				}
			}

			function publish(message, channel) {
				pubnub.publish({
					channel: channel,
					message: message
				});
			}
			window.initializemap = initializemap;

			function getAddress(location) {
				return new Promise(function (resolve, reject) {
					var method = "GET";
					var async = true;
					var url =
						`https://maps.googleapis.com/maps/api/geocode/json?latlng=${location.lat},${location.lng}&key=AIzaSyCqjMdWdNss5BgNzucIYPBBMGkKs7Y5dlI`;
					var request = new XMLHttpRequest();
					request.open(method, url, async);
					request.onreadystatechange = function () {
						if (request.readyState == 4) {
							if (request.status == 200) {
								var data = JSON.parse(request.responseText);
								resolve(data.results[0].formatted_address);
							} else {
								reject(request.status);
							}
						}
					};
					request.send();
				});
			}
			var gScript = document.createElement('script');
			gScript.async = true;
			gScript.defer = true;
			gScript.src =
				"https://maps.googleapis.com/maps/api/js?v=3.exp&libraries=geometry&key=AIzaSyCqjMdWdNss5BgNzucIYPBBMGkKs7Y5dlI&callback=initializemap";
			document.body.appendChild(gScript);

			$(function () {
				var handle = $("#custom-handle");
				var slidervalue = $("#slider-value");
				$('#slider').slider({
					create: function () {
						handle.text($(this).slider("value") + " Km");
						slidervalue.val($(this).slider("value"));
					},
					slide: function (event, ui) {
						handle.text(ui.value + " Km");
						slidervalue.val(ui.value);
					},
					min: 0,
					max: 5000,
					step: 50
				});

				window.companytable = $(".table-company").DataTable({
					"language": {
						"emptyTable": "No tow companies are online in this area. "
					},
					"createdRow": function (row, data, index) {
						var username = data[0];
						$('td', row).eq(0).attr('data-name', username);
						$(row).attr('data-name', username);
					},
					"createdCell": function (td, cellData, rowData, row, col) {

					}
				});
			});
		</script>
	</body>

	</html>
	<?php
?>